/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Modelo;

/**
 *
 * @author Oscar
 */
public class Equipos {

    private String Nro_de_Serie;
    private String TipodeEquipo,Marca,Modelo,Pertenece,Sala_de_Ubicacion,Estado,Funcionamiento,Observaciones ;

    public String getNro_de_Serie() {
        return Nro_de_Serie;
    }

    public void setNro_de_Serie(String Nro_de_Serie) {
        this.Nro_de_Serie = Nro_de_Serie;
    }

    public String getTipodeEquipo() {
        return TipodeEquipo;
    }

    public void setTipodeEquipo(String TipodeEquipo) {
        this.TipodeEquipo = TipodeEquipo;
    }

    public String getMarca() {
        return Marca;
    }

    public void setMarca(String Marca) {
        this.Marca = Marca;
    }

    public String getModelo() {
        return Modelo;
    }

    public void setModelo(String Modelo) {
        this.Modelo = Modelo;
    }

    public String getPertenece() {
        return Pertenece;
    }

    public void setPertenece(String Pertenece) {
        this.Pertenece = Pertenece;
    }

    public String getSala_de_Ubicacion() {
        return Sala_de_Ubicacion;
    }

    public void setSala_de_Ubicacion(String Sala_de_Ubicacion) {
        this.Sala_de_Ubicacion = Sala_de_Ubicacion;
    }

    public String getEstado() {
        return Estado;
    }

    public void setEstado(String Estado) {
        this.Estado = Estado;
    }

    public String getFuncionamiento() {
        return Funcionamiento;
    }

    public void setFuncionamiento(String Funcionamiento) {
        this.Funcionamiento = Funcionamiento;
    }

    public String getObservaciones() {
        return Observaciones;
    }

    public void setObservaciones(String Observaciones) {
        this.Observaciones = Observaciones;
    }
    
    

}
